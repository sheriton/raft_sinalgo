package projects.raft.nodes.nodeImplementations;

public enum RaftState {
	LEADER,
	CANDIDATE,
	FOLLOWER,
}
